package com.example.seating.entity;

public enum RoomType {
    ROOM_8X8,
    ROOM_8X12
}
